// Use relative path so the frontend talks to the same host/port the app is served from.
// If you run the backend on a different port (e.g. 8081) you can also set the absolute URL.
const API_URL = "/personas"; // previously pointed to http://localhost:8080/personas

// Cargar lista al iniciar
document.addEventListener("DOMContentLoaded", cargarVehiculos);

// Manejar envío del formulario
document.getElementById("vehiculoForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  
  const marca = document.getElementById("marca").value;
  const precio = document.getElementById("precio").value;

  const nuevoVehiculo = {
    nombre: marca,
    edad: precio
  };

  await fetch(`${API_URL}/crear`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(nuevoVehiculo)
  });

  document.getElementById("vehiculoForm").reset();
  cargarVehiculos();
});

// Obtener lista
async function cargarVehiculos() {
  const response = await fetch(`${API_URL}/traer`);
  const vehiculos = await response.json();

  const tabla = document.getElementById("tablaVehiculos");
  tabla.innerHTML = "";

  vehiculos.forEach(v => {
    const fila = `
      <tr>
        <td>${v.id}</td>
        <td>${v.nombre}</td>
        <td>${v.edad}</td>
        <td><button class="eliminar" onclick="eliminarVehiculo(${v.id})">Eliminar</button></td>
      </tr>
    `;
    tabla.innerHTML += fila;
  });
}

// Eliminar vehículo
async function eliminarVehiculo(id) {
  if (confirm("¿Seguro que querés eliminar este vehículo?")) {
    await fetch(`${API_URL}/borrar/${id}`, { method: "DELETE" });
    cargarVehiculos();
  }
}

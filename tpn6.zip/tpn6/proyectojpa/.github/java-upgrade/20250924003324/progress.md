# Upgrade Progress

  ### ❗ Generate Upgrade Plan
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - "GitHub Copilot app modernization - upgrade for Java" and its tools are only available for GitHub Copilot "Pro", "Pro+", "Business" and "Enterprise" plans.. Please upgrade your GitHub Copilot plan to use this feature or upgrading this project using other tools you prefer.
  
  
  
  </details>